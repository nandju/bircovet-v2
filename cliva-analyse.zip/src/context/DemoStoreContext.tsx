"use client";

/**
 * Magasin de données de DÉMONSTRATION (localStorage, versionné).
 * - aucune donnée réelle, aucun mot de passe réel ;
 * - accès à localStorage uniquement côté client (après montage) ;
 * - données absentes / corrompues / d'une ancienne version → jeu initial restauré.
 * MODE CONNECTÉ (API) : si NEXT_PUBLIC_API_URL est définie, ce magasin
 * bascule sur l'API NestJS — exécution locale optimiste inchangée, puis envoi
 * de chaque opération à POST /api/ops (file ordonnée, idempotente par opKey)
 * et rechargement de l'état validé par le serveur. Sans cette variable,
 * le mode démo localStorage reste strictement identique.
 */
import { useToast } from "@/context/ToastContext";
import { LogoMark } from "@/icons";
import ChangePasswordScreen from "@/components/auth/ChangePasswordScreen";
import {
  apiMode, apiLogin, apiLogout, apiMe, apiGetState, apiGetVersion, apiPostOp, apiRefresh,
  ApiNetworkError, clearAccessToken, type PendingOp,
} from "@/lib/api";
import { loadPendingOps, savePendingOps } from "@/lib/offlineQueue";
import { OPERATIONS } from "@/lib/services/registry";
import { markNotificationsRead as markNotificationsReadSvc } from "@/lib/services/notificationsService";
import { isMvpModule, LOCAL_ONLY_API_OPS } from "@/lib/mvp";
import { isoLocal } from "@/lib/format";
import { applyRoleSettings, can as canRole, type ModuleId, type PermAction } from "@/lib/permissions";
import { applyCategoryList, applyLabelOverrides } from "@/lib/labels";
import { migrateToV6 } from "@/lib/followup";
import { migrateToV8 } from "@/lib/pharma/state";
import { migrateToV9 } from "@/lib/clientActivity";
import { migrateToV10 } from "@/lib/announcements";
import { migrateToV11 } from "@/lib/migrateV11";
import { migrateToV12 } from "@/lib/migrateV12";
import { migrateToV13 } from "@/lib/migrateV13";
import { migrateToV14 } from "@/lib/migrateV14";
import { migrateToV15 } from "@/lib/migrateV15";
import { migrateToV16 } from "@/lib/migrateV16";
import { migrateToV17 } from "@/lib/migrateV17";
import { migrateToV18 } from "@/lib/migrateV18";
import { migrateToV19 } from "@/lib/migrateV19";
import { migrateToV20 } from "@/lib/migrateV20";
import { migrateToV21 } from "@/lib/migrateV21";
import { migrateToV22 } from "@/lib/migrateV22";
import { migrateToV23 } from "@/lib/migrateV23";
import { migrateToV7 } from "@/lib/rural";
import { SCHEMA_VERSION, createSeed } from "@/lib/seed";
import { executeService, refreshDerived, type Service } from "@/lib/services/core";
import type { ActionCtx, DemoDB, Establishment, ServiceResult, SessionState, User } from "@/lib/types";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";

/** Comptes de connexion : équipe de la clinique + compte éditeur de la plateforme. */
function accountsOf(db: DemoDB) {
  return db.platform ? [...db.users, db.platform.editor] : db.users;
}

export const DB_KEY = "cliva.demo.db";
export const SESSION_KEY = "cliva.demo.session";
const EMPTY_SESSION: SessionState = { userId: null, establishmentId: null, offline: false };

export const nowIso = () => {
  const d = new Date();
  return `${isoLocal(d)}:${String(d.getSeconds()).padStart(2, "0")}`;
};

/** Nom d'opération du registre ↔ fonction de service (pour l'envoi à l'API). */
const OP_NAMES = new Map<unknown, string>(Object.entries(OPERATIONS).map(([name, def]) => [def.fn, name]));

interface DemoStore {
  db: DemoDB;
  session: SessionState;
  user: User | null;
  establishment: Establishment | null;
  today: string;
  /** true = mode connecté (API NestJS) ; false = démo localStorage. */
  apiMode: boolean;
  run: <I, T = undefined>(svc: Service<I, T>, input: I, opts?: { silent?: boolean; auto?: boolean }) => ServiceResult<T>;
  can: (m: ModuleId, a?: PermAction) => boolean;
  login: (email: string, password: string) => { ok: boolean; error?: string } | Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
  switchUser: (userId: string) => void;
  setEstablishment: (id: string) => void;
  setOffline: (offline: boolean) => void;
  resetDemo: () => void;
  markNotificationsRead: () => void;
  /** Mode connecté : recharge l'état depuis le serveur (après un appel REST hors /ops). */
  refresh: () => Promise<void>;
}

const DemoStoreContext = createContext<DemoStore | undefined>(undefined);

export const useDemo = () => {
  const c = useContext(DemoStoreContext);
  if (!c) throw new Error("useDemo must be used within DemoStoreProvider");
  return c;
};

function isValidDb(x: unknown): x is DemoDB {
  if (!x || typeof x !== "object") return false;
  const d = x as Partial<DemoDB>;
  return (d.schemaVersion === SCHEMA_VERSION || d.schemaVersion === 5 || d.schemaVersion === 6 || d.schemaVersion === 7 || d.schemaVersion === 8 || d.schemaVersion === 9 || d.schemaVersion === 10 || d.schemaVersion === 11 || d.schemaVersion === 12 || d.schemaVersion === 13 || d.schemaVersion === 14 || d.schemaVersion === 15 || d.schemaVersion === 16 || d.schemaVersion === 17 || d.schemaVersion === 18 || d.schemaVersion === 19 || d.schemaVersion === 20 || d.schemaVersion === 21 || d.schemaVersion === 22) && Array.isArray(d.clients) && Array.isArray(d.users) && Array.isArray(d.invoices) && !!d.settings && !!d.counters;
}

/** Met à niveau une base enregistrée par une version précédente sans perdre les données saisies. */
function upgrade(d: DemoDB): DemoDB {
  let x = d;
  if (x.schemaVersion === 5) x = migrateToV6(x, nowIso().slice(0, 10));
  if (x.schemaVersion === 6) x = migrateToV7(x, nowIso());
  if (x.schemaVersion === 7) x = migrateToV8(x);
  if (x.schemaVersion === 8) x = migrateToV9(x, nowIso().slice(0, 10));
  if (x.schemaVersion === 9) x = migrateToV10(x, nowIso().slice(0, 10));
  if (x.schemaVersion === 10) x = migrateToV11(x, isoLocal());
  if (x.schemaVersion === 11) x = migrateToV12(x, isoLocal());
  if (x.schemaVersion === 12) x = migrateToV13(x, isoLocal());
  if (x.schemaVersion === 13) x = migrateToV14(x, isoLocal());
  if (x.schemaVersion === 14) x = migrateToV15(x, isoLocal());
  if (x.schemaVersion === 15) x = migrateToV16(x, isoLocal());
  if (x.schemaVersion === 16) x = migrateToV17(x, isoLocal());
  if (x.schemaVersion === 17) x = migrateToV18(x, isoLocal());
  if (x.schemaVersion === 18) x = migrateToV19(x, isoLocal());
  if (x.schemaVersion === 19) x = migrateToV20(x, isoLocal());
  if (x.schemaVersion === 20) x = migrateToV21(x, isoLocal());
  if (x.schemaVersion === 21) x = migrateToV22(x);
  if (x.schemaVersion === 22) x = migrateToV23(x);
  return x;
}

function loadDb(): { db: DemoDB; restored: boolean } {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) {
      const parsed: unknown = JSON.parse(raw);
      if (isValidDb(parsed)) return { db: upgrade(parsed), restored: false };
    }
    return { db: createSeed(new Date()), restored: !!raw };
  } catch {
    return { db: createSeed(new Date()), restored: true };
  }
}

function loadSession(): SessionState {
  try {
    const s = JSON.parse(localStorage.getItem(SESSION_KEY) ?? "null") as SessionState | null;
    return s && typeof s === "object" ? { ...EMPTY_SESSION, ...s } : EMPTY_SESSION;
  } catch {
    return EMPTY_SESSION;
  }
}

/** UUID v4 — crypto.randomUUID si disponible, sinon vrai v4 via crypto.getRandomValues. */
const newOpKey = (): string => {
  const c = typeof crypto !== "undefined" ? crypto : undefined;
  if (c?.randomUUID) return c.randomUUID();
  const b = new Uint8Array(16);
  if (c?.getRandomValues) c.getRandomValues(b);
  else for (let i = 0; i < 16; i += 1) b[i] = Math.floor(Math.random() * 256);
  b[6] = (b[6] & 0x0f) | 0x40; // version 4
  b[8] = (b[8] & 0x3f) | 0x80; // variante RFC 4122
  const h = Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
};

export function DemoStoreProvider({ children }: { children: React.ReactNode }) {
  const toast = useToast();
  const [db, setDb] = useState<DemoDB | null>(null);
  const [session, setSession] = useState<SessionState>(EMPTY_SESSION);
  const [mustChange, setMustChange] = useState(false);
  const dbRef = useRef<DemoDB | null>(null);
  const quotaWarnedRef = useRef(false);
  // Mode connecté : dernière version serveur connue + file d'envoi ordonnée.
  const serverVersionRef = useRef(0);
  const queueRef = useRef<PendingOp[]>([]);
  // File persistée en IndexedDB, UNE file PAR COMPTE (clé = accountId du
  // jeton) : le rejeu ne concerne jamais les opérations d'un autre compte.
  const queueKeyRef = useRef<string | null>(null);
  const [pendingCount, setPendingCount] = useState(0);
  // Garde-fou anti-rafale : horodatages des opérations marquées « auto »
  // (appels non déclenchés par un clic ou une saisie — intervalles, effets).
  const autoOpsRef = useRef<number[]>([]);
  const autoWarnRef = useRef(0);
  const sendingRef = useRef(false);
  const offlineToastRef = useRef(false);

  const persist = useCallback(
    (next: DemoDB) => {
      dbRef.current = next;
      setDb(next);
      if (apiMode) return; // mode connecté : l'état de référence vit sur le serveur
      try {
        localStorage.setItem(DB_KEY, JSON.stringify(next));
        quotaWarnedRef.current = false;
      } catch {
        if (!quotaWarnedRef.current) {
          quotaWarnedRef.current = true;
          toast.show("error", "Stockage local saturé : les dernières modifications restent affichées mais ne seront pas conservées au rechargement. Supprimez des photos/pièces jointes volumineuses ou réinitialisez la démo (Administration → Démo).");
        }
      }
    },
    [toast],
  );

  const saveSession = useCallback((s: SessionState) => {
    setSession(s);
    if (apiMode) return; // mode connecté : la session réelle est le cookie httpOnly
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify(s));
    } catch {
      /* ignoré : session non persistée */
    }
  }, []);

  /** Mode connecté : applique un état validé par le serveur. */
  const applyServerState = useCallback((data: DemoDB, version: number) => {
    serverVersionRef.current = version;
    const fresh = refreshDerived(data, nowIso().slice(0, 10));
    dbRef.current = fresh;
    setDb(fresh);
  }, []);

  /** Mode connecté : recharge l'état complet depuis le serveur. */
  const reloadState = useCallback(async () => {
    try {
      const st = await apiGetState();
      applyServerState(st.data, st.version);
    } catch {
      /* réessayé par l'interrogation périodique */
    }
  }, [applyServerState]);

  /** Met à jour le compteur du bandeau + la copie IndexedDB après tout ajout/retrait. */
  const touchQueue = useCallback(() => {
    setPendingCount(queueRef.current.length);
    if (queueKeyRef.current) void savePendingOps(queueKeyRef.current, [...queueRef.current]);
  }, []);

  /** Mode connecté : envoie la file UNE opération à la fois, dans l'ordre. */
  const pumpQueue = useCallback(async () => {
    if (sendingRef.current) return;
    sendingRef.current = true;
    try {
      // Version connue avant mes envois + nombre d'envois réussis : à la fin,
      // on ne recharge que si la version a avancé AU-DELÀ de mes propres ops
      // (un autre poste a écrit) — sinon l'état local optimiste est déjà juste.
      const versionBefore = serverVersionRef.current;
      let okCount = 0;
      while (queueRef.current.length > 0) {
        const op = queueRef.current[0];
        try {
          const res = await apiPostOp(op);
          queueRef.current.shift();
          touchQueue();
          offlineToastRef.current = false;
          if (res.ok) okCount += 1;
          else {
            // Refus métier : l'état local optimiste est faux → on resynchronise.
            toast.show("error", res.error ?? "Opération refusée par le serveur.");
            await reloadState();
          }
        } catch (e) {
          if (e instanceof ApiNetworkError) {
            // Erreur réseau : on garde l'opération (même opKey) et on réessaie plus tard.
            if (!offlineToastRef.current) {
              offlineToastRef.current = true;
              toast.show("warning", "Envoi en attente : serveur injoignable, nouvelle tentative automatique.");
            }
            setTimeout(() => void pumpQueue(), 5000);
            return;
          }
          // Erreur HTTP (400/403…) : opération rejetée définitivement.
          queueRef.current.shift();
          touchQueue();
          toast.show("error", e instanceof Error ? e.message : "Opération rejetée par le serveur.");
          await reloadState();
        }
      }
      if (okCount > 0) {
        try {
          const { version } = await apiGetVersion();
          if (version === versionBefore + okCount) {
            // La nouvelle version correspond exactement à mes envois.
            serverVersionRef.current = version;
          } else {
            await reloadState();
          }
        } catch {
          /* serveur injoignable : l'interrogation périodique reprendra le relais */
        }
      }
    } finally {
      sendingRef.current = false;
    }
  }, [reloadState, toast, touchQueue]);

  /**
   * Mode connecté : restaure la file persistée de CE compte (IndexedDB) puis
   * la rejoue dans l'ordre — mêmes opKey, le serveur ignore celles déjà
   * reçues. L'état est ensuite rechargé UNE fois (la version a avancé de mes
   * envois) : pas de boucle, pas de remontage de l'interface.
   */
  const replayQueue = useCallback(
    async (accountId: string) => {
      queueKeyRef.current = accountId;
      const ops = await loadPendingOps(accountId);
      if (ops.length === 0) return;
      queueRef.current.push(...ops);
      touchQueue();
      await pumpQueue();
      if (queueRef.current.length === 0) await reloadState();
    },
    [touchQueue, pumpQueue, reloadState],
  );

  /** Mode connecté : session issue du compte API + état serveur. */
  const bootstrapApi = useCallback(async () => {
    const ok = await apiRefresh();
    if (!ok) {
      // Pas de session : écran de connexion (placeholder local, jamais persisté).
      dbRef.current = createSeed(new Date());
      setDb(dbRef.current);
      setSession(EMPTY_SESSION);
      return;
    }
    try {
      const me = await apiMe();
      const st = await apiGetState();
      applyServerState(st.data, st.version);
      const u = st.data.users.find((x) => x.id === me.userId);
      setMustChange(me.mustChangePassword);
      setSession({ userId: me.userId, establishmentId: u?.establishmentId ?? null, offline: false });
      await replayQueue(me.id); // rejoue les envois interrompus de ce compte
    } catch {
      dbRef.current = createSeed(new Date());
      setDb(dbRef.current);
      setSession(EMPTY_SESSION);
      toast.show("error", "Impossible de charger les données depuis le serveur. Reconnectez-vous.");
    }
  }, [applyServerState, toast, replayQueue]);

  useEffect(() => {
    if (apiMode) {
      void bootstrapApi();
      return; // pas de localStorage ni d'écoute inter-onglets en mode connecté
    }
    const { db: loaded, restored } = loadDb();
    const fresh = refreshDerived(loaded, nowIso().slice(0, 10));
    persist(fresh);
    setSession(loadSession());
    if (restored) toast.show("warning", "Données locales absentes, obsolètes ou corrompues : le jeu de démonstration initial a été restauré.");
    const onStorage = (e: StorageEvent) => {
      if (e.key === DB_KEY && e.newValue) {
        try {
          const parsed: unknown = JSON.parse(e.newValue);
          if (isValidDb(parsed)) {
            const up = upgrade(parsed);
            dbRef.current = up;
            setDb(up);
          }
        } catch {
          /* ignoré */
        }
      }
      if (e.key === SESSION_KEY) setSession(loadSession());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Mode connecté : toutes les 10 s et au retour sur l'onglet, comparer la
  // version serveur ; recharger l'état si elle a changé et que la file est vide.
  useEffect(() => {
    if (!apiMode || !session.userId) return;
    const check = async () => {
      if (queueRef.current.length > 0 || sendingRef.current) return;
      try {
        const { version } = await apiGetVersion();
        if (version !== serverVersionRef.current && queueRef.current.length === 0) {
          serverVersionRef.current = version;
          await reloadState();
        }
      } catch {
        /* serveur injoignable : on réessaiera au prochain tour */
      }
    };
    const interval = setInterval(() => void check(), 10_000);
    const onVisible = () => {
      if (document.visibilityState === "visible") void check();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [session.userId, reloadState]);

  // Mode connecté : avertir avant de fermer l'onglet si des envois attendent.
  useEffect(() => {
    if (!apiMode) return;
    const warn = (e: BeforeUnloadEvent) => {
      if (queueRef.current.length > 0) e.preventDefault();
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, []);

  const user = useMemo(() => (db && session.userId ? (accountsOf(db).find((u) => u.id === session.userId && u.active) ?? null) : null), [db, session.userId]);
  const establishment = useMemo(
    () => (db ? (db.establishments.find((e) => e.id === (session.establishmentId ?? user?.establishmentId)) ?? db.establishments[0]) : null),
    [db, session.establishmentId, user],
  );

  const run = useCallback(
    <I, T = undefined>(svc: Service<I, T>, input: I, opts?: { silent?: boolean; auto?: boolean }): ServiceResult<T> => {
      const current = dbRef.current;
      if (!current || !user || !establishment) {
        const r = { ok: false as const, error: "Session expirée : reconnectez-vous." };
        toast.show("error", r.error);
        return r;
      }
      const now = nowIso();
      if (apiMode && !OP_NAMES.get(svc)) {
        // Mode connecté : une opération absente du registre ne peut PAS être
        // enregistrée côté serveur — on refuse tout de suite plutôt que de
        // laisser croire qu'elle a réussi puis la perdre au rechargement.
        const r = { ok: false as const, error: "Cette fonction n'est pas encore disponible dans la version de test." };
        toast.show("error", r.error);
        if (process.env.NODE_ENV === "development") {
          console.warn("[Cliva API] Opération absente du registre OPERATIONS : ajoutez-la dans src/lib/services/registry.ts pour l'activer.", svc.name || svc);
        }
        return r;
      }
      // opKey : clé unique de l'opération (idempotence + ids déterministes, cf. executeService).
      const opKey = newOpKey();
      const ctx: ActionCtx = { user, establishmentId: establishment.id, offline: session.offline, now, opKey };
      const r = executeService(svc, current, ctx, input);
      if (r.ok) {
        persist(refreshDerived(r.db, now.slice(0, 10)));
        if (!opts?.silent && r.message) toast.show("success", r.message);
        if (apiMode) {
          // Mode connecté : envoi de l'opération au serveur (file ordonnée).
          // OP_NAMES.get(svc) est garanti non nul (vérifié avant l'exécution).
          // Les ops de LOCAL_ONLY_API_OPS (compteurs, scan d'alertes, « lu »)
          // restent locales : elles ne doivent pas faire avancer la version
          // partagée ni provoquer de rechargement chez les autres postes.
          const name = OP_NAMES.get(svc) as string;
          if (!LOCAL_ONLY_API_OPS.has(name)) {
            let allow = true;
            if (opts?.auto) {
              // Ops marquées « auto » (intervalle, effet de montage — jamais un
              // clic ou une saisie) : si plus de 10 partent en moins d'une
              // minute, c'est forcément une boucle — on suspend l'envoi et on
              // avertit (la donnée reste appliquée localement).
              const t = Date.now();
              autoOpsRef.current = autoOpsRef.current.filter((x) => t - x < 60_000);
              if (autoOpsRef.current.length >= 10) {
                allow = false;
                if (t - autoWarnRef.current > 60_000) {
                  autoWarnRef.current = t;
                  console.warn(`[Cliva API] Plus de 10 opérations automatiques en moins d'une minute (dernière : ${name}) — envoi suspendu pour cette rafale. Vérifiez les appels run(..., { auto: true }).`);
                }
              } else autoOpsRef.current.push(t);
            }
            if (allow) {
              queueRef.current.push({ opKey, name, input, clientNow: new Date().toISOString() });
              touchQueue(); // bandeau + sauvegarde IndexedDB du compte
              void pumpQueue();
            }
          }
        }
      } else if (!opts?.silent) toast.show("error", r.error);
      return r;
    },
    [user, establishment, session.offline, persist, toast, pumpQueue, touchQueue],
  );

  const login = useCallback(
    (email: string, password: string): { ok: boolean; error?: string } | Promise<{ ok: boolean; error?: string }> => {
      if (apiMode) {
        // Mode connecté : authentification réelle puis chargement de l'état serveur.
        return (async () => {
          const r = await apiLogin(email.trim(), password);
          if (!r.ok) return r;
          try {
            const me = await apiMe();
            const st = await apiGetState();
            applyServerState(st.data, st.version);
            const u = st.data.users.find((x) => x.id === me.userId);
            setMustChange(r.mustChangePassword);
            setSession({ userId: me.userId, establishmentId: u?.establishmentId ?? null, offline: false });
            await replayQueue(me.id); // rejoue les envois interrompus de ce compte
            return { ok: true };
          } catch {
            return { ok: false, error: "Connexion réussie mais chargement des données impossible. Réessayez." };
          }
        })();
      }
      const u = dbRef.current ? accountsOf(dbRef.current).find((x) => x.email.toLowerCase() === email.trim().toLowerCase()) : undefined;
      if (!u || u.demoPassword !== password) return { ok: false, error: "Identifiant ou mot de passe incorrect." };
      if (!u.active) return { ok: false, error: "Ce compte est désactivé." };
      saveSession({ userId: u.id, establishmentId: u.establishmentId, offline: false });
      return { ok: true };
    },
    [saveSession, applyServerState, replayQueue],
  );

  // Réglages du DG (droits, libellés) appliqués avant tout rendu.
  applyRoleSettings(db?.settings.permissions, db?.settings.roleLabels);
  applyLabelOverrides({ category: db?.settings.categoryLabels ?? {} });
  applyCategoryList(db?.settings.productCategories);
  const value = useMemo<DemoStore | null>(() => {
    if (!db) return null;
    return {
      db,
      session,
      user,
      establishment,
      today: nowIso().slice(0, 10),
      apiMode,
      run,
      can: (m, a = "read") => canRole(user?.roleId, m, a) && (!apiMode || isMvpModule(m)),
      login,
      logout: () => {
        if (apiMode) void apiLogout(); // révoque le cookie côté serveur
        clearAccessToken();
        // La copie IndexedDB reste sous l'ANCIEN compte (rejeu à sa prochaine
        // connexion) — le prochain utilisateur de ce navigateur n'hérite
        // jamais des envois en attente d'un autre.
        queueRef.current = [];
        queueKeyRef.current = null;
        setPendingCount(0);
        saveSession(EMPTY_SESSION);
      },
      switchUser: (userId) => {
        if (apiMode) {
          toast.show("info", "Changement de profil indisponible en mode connecté : déconnectez-vous puis reconnectez-vous avec un autre compte.");
          return;
        }
        const u = accountsOf(db).find((x) => x.id === userId && x.active);
        if (u) {
          saveSession({ ...session, userId: u.id, establishmentId: u.establishmentId });
          toast.show("info", `Profil de démonstration actif : ${u.name}.`);
        }
      },
      setEstablishment: (id) => saveSession({ ...session, establishmentId: id }),
      setOffline: (offline) => {
        if (apiMode) {
          toast.show("info", "Simulation hors ligne indisponible en mode connecté.");
          return;
        }
        saveSession({ ...session, offline });
        toast.show(offline ? "warning" : "info", offline ? "Mode hors ligne — Simulation activé." : "Connexion simulée rétablie. Pensez à synchroniser les opérations en attente.");
      },
      resetDemo: () => {
        if (apiMode) {
          toast.show("info", "Réinitialisation indisponible en mode connecté : les données vivent sur le serveur.");
          return;
        }
        const fresh = refreshDerived(createSeed(new Date()), nowIso().slice(0, 10));
        persist(fresh);
        toast.show("success", "Environnement de démonstration réinitialisé : données initiales restaurées.");
      },
      markNotificationsRead: () => {
        run(markNotificationsReadSvc, {}, { silent: true });
      },
      refresh: reloadState,
    };
  }, [db, session, user, establishment, run, login, saveSession, persist, toast, reloadState]);

  if (!value) return <SplashScreen />;
  // Mode connecté : mot de passe initial à remplacer avant d'utiliser l'application.
  // L'écran est rendu DANS le Provider : il utilise ClivaLogo → useDemo().
  return (
    <DemoStoreContext.Provider value={value}>
      {apiMode && pendingCount > 0 && (
        <div
          role="status"
          className="fixed bottom-4 start-1/2 z-999999 -translate-x-1/2 rounded-full bg-warning-500 px-4 py-2 text-theme-xs font-medium text-white shadow-theme-lg rtl:translate-x-1/2"
        >
          {pendingCount} action{pendingCount > 1 ? "s" : ""} en attente d&apos;envoi
        </div>
      )}
      {apiMode && mustChange && user ? (
        <ChangePasswordScreen
          onDone={() => {
            // Recharge l'état serveur puis affiche l'application (sans reconnexion).
            void reloadState();
            setMustChange(false);
            toast.show("success", "Mot de passe enregistré.");
          }}
        />
      ) : (
        children
      )}
    </DemoStoreContext.Provider>
  );
}

export function SplashScreen({ label = "Chargement de l'environnement de démonstration…" }: { label?: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-gray-50 dark:bg-gray-900">
      <LogoMark className="size-14 animate-pulse" />
      <p className="text-sm text-gray-500 dark:text-gray-400">{label}</p>
    </div>
  );
}
