import QuoteDetail from "@/components/billing/QuoteDetail";
import { initIdPage, type IdParams } from "@/i18n/page";
import type { Metadata } from "next";

export const metadata: Metadata = { title: "Devis" };

export default async function Page({ params }: IdParams) {
  const id = await initIdPage(params);
  return <QuoteDetail id={id} />;
}
